TLM Automations Website
========================
Files:
- index.html
- style.css
- script.js

Open index.html in a browser to preview.

Free hosting:
1. Create a GitHub account.
2. Create a public repository, e.g. tlm-automations-website.
3. Upload these 3 files.
4. Settings -> Pages -> Deploy from branch -> main -> /root.
5. GitHub Pages gives you a free website address.

Custom domain:
Later, connect tlmautomations.com to the hosting provider using its DNS instructions.

Before publishing, verify the phone/email/address and replace any placeholder project images/text with your actual company content.
